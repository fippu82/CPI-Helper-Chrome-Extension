// template = - [header :your header as HTML] [description": "description goes here as HTML] ,... //multiple
const whats_new_log = `
- [Plugin] Environment Traffic Light Plugin shows an indicator about your landscape. Special thanks to Aman Anand
- [Plugin] GroovyDebugX IDE Plugin works now with groovy Script v2. Special thanks to Sunil Pharswan.
`;
