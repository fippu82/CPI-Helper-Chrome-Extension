// template = - [header :your header as HTML] [description": "description goes here as HTML] ,... //multiple
const whats_new_log = `
- [Plugin] GroovyDebugX IDE Plugin to send payload, headers and properties to external IDE. Special thanks to Sunil Pharswan.
- [Fix] Better error handling when fetching api messages
`;
